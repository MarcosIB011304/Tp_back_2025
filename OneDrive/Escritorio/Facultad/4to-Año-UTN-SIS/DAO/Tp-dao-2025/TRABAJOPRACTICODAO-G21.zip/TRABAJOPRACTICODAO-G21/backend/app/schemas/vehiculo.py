from typing import Optional
from datetime import date
from pydantic import Field, BaseModel
from pydantic import BaseModel, EmailStr, Field, ConfigDict

#Marca

class MarcaBase(BaseModel):
    nombre: str = Field(..., min_length=1, max_length=80)
    habilitada: bool = True

class MarcaCreate(MarcaBase):
    pass

class MarcaUpdate(BaseModel):
    nombre: Optional[str] = Field(None, min_length=1, max_length=80)
    habilitada: Optional[bool] = None

class MarcaOut(MarcaBase):
    id: int
    modelos: list["ModeloOut"] = []
    class Config:
        from_attributes = True
class MarcaSimpleOut(MarcaBase): # este es para la salida en modelos, si devuelve la marca entera se hace un bucle infinito
    id: int
    class Config:
        from_attributes = True

#Modelo, le usmos la misma base

class ModeloBase(BaseModel):
    nombre: str= Field(..., min_length=1, max_length=180)
    habilitada: bool = True
    stock: int = 0
    marca_id: int 

class ModeloCreate(ModeloBase):
    marca_id : int

class ModeloUpdate(BaseModel):
    nombre: Optional[str] = Field(None,  max_length=180)
    stock: Optional[int] = None

class ModeloOut(ModeloBase):
    id:int
    marca:"MarcaSimpleOut"

    class Config:
        from_attributes = True
class ModeloSimpleOut(ModeloBase):
    id: int
    class Config:
        from_attributes= True
##Vehculo

class VehiculoBase(BaseModel):
    patente: str = Field(..., min_length=6, max_length=12)
    añoModelo:int
    añoIngreso:int
    kilometros: float 
    precioPorDia: float 
    color: str= Field(..., min_length=4, max_length=15)
    disponibleHoy: bool
    modelo_id: int
class VehiculoCreate(VehiculoBase):
    modelo_id: int
class VehiculoOut(VehiculoBase):
    patente: str
    modelo: "ModeloSimpleOut"
class VehiculoSimpleOut(VehiculoBase):
    patente: str
    class Config:
        from_attributes: True


MarcaOut.model_rebuild()
ModeloOut.model_rebuild()
VehiculoOut.model_rebuild()