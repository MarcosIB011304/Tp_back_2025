from typing import Optional
from datetime import date
from pydantic import Field, BaseModel, ConfigDict


class CobroBase (BaseModel):
    alquiler_id: int
    monto: float
    formaDePago: str
    fechaPago: date
    desc: str

class CobroCreate(CobroBase):
    pass

class CobroOut(CobroBase):
    nroCobro: int
    class Config:
        from_attributes = True



CobroOut.model_rebuild()