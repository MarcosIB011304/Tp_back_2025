import apiClient from "./apiClient";

// Obtener todos los clientes
export const getClientes = async () => {
  const response = await apiClient.get("/clientes");
  return response.data;
};

// Crear cliente
export const createCliente = (clienteData) => {
  const dataConFecha = {
    ...clienteData,
    fechaAlta: new Date().toISOString().split("T")[0], // YYYY-MM-DD
  };

  // Si dirección no existe, eliminarla del payload
  if (!dataConFecha.direccion) {
    delete dataConFecha.direccion;
  }

  return apiClient.post("/clientes", dataConFecha).then((res) => res.data);
};

// Actualizar cliente
export const updateCliente = (id, clienteData) => {
  const payload = { ...clienteData };

  if (!payload.direccion) {
    delete payload.direccion;
  }

  return apiClient.patch(`/clientes/${id}`, payload);
};

// Eliminar cliente
export const deleteCliente = (id) => {
  return apiClient.delete(`/clientes/${id}`);
};

// Obtener alquileres asociados a un cliente
export const getAlquileresDeCliente = (clienteId) => {
  return apiClient.get(`/clientes/${clienteId}/alquileres`);
};
