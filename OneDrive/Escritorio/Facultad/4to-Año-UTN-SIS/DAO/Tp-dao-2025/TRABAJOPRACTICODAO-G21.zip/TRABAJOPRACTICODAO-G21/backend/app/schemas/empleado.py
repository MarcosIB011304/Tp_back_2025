from typing import Optional
from datetime import date
from pydantic import Field, BaseModel
from pydantic import BaseModel, EmailStr, Field, ConfigDict

# -------- Empleado --------
class EmpleadoBase(BaseModel):
    nombreUsuario: str
    nombre: str
    apellido: str
    fechaAlta: str            
    password_hash: str
    permisos: str = "user"

    class Config:
        orm_mode = True

class EmpleadoCreate(EmpleadoBase):
    dni: int

class EmpleadoUpdate(BaseModel):
    nombreUsuario: Optional[str] = None
    nombre: Optional[str] = None
    apellido: Optional[str] = None
    fechaAlta: Optional[str] = None
    password_hash: Optional[str] = None
    permisos: Optional[str] = None

    class Config:
        orm_mode = True

class EmpleadoOut(EmpleadoBase):
    dni: int


EmpleadoOut.model_rebuild()