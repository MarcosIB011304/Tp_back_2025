import apiClient from "./apiClient";


const getMarcas = async ()=>{
    const response = await apiClient.get("/marcas")
    return response.data
}

const crearMarca = async (nuevaMarca)=>{
    const response = await apiClient.post("/marcas", nuevaMarca)
    return response.data
}

const getModelos = async ()=>{
    const response = await apiClient.get("/modelos")
    return response.data
}
const crearModelo = async (nuevoModelo)=>{
    const response = await apiClient.post("/modelos", nuevoModelo)
    return response.data
}

const mymService = {getMarcas, getModelos, crearMarca, crearModelo}

export default mymService