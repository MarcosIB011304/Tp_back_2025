import { useCallback, useEffect, useState } from "react";
import vehiculosService from "../services/vehiculosService";

export const useVehiculos = ()=>{
    const [vehiculos, setVehiculos] = useState([])
    const [loading, setLoading] = useState(false)
    const [error, setError] = useState(null)


    const fetchVehiculos = useCallback(async ()=> {
        setLoading(true)
        setError(null)
        try{
            const data = await vehiculosService.getVehiculos();
            setVehiculos(data);
            console.log("Hook de vehiculos obtuvo correctamente la info")
        }
        catch(e){
            setError(e)
            console.error('Error al carga los vehiculos', e.message)    
        }
        finally{
            setLoading(false)
        }
    }, [])

    useEffect(()=>{
        fetchVehiculos();

    },[fetchVehiculos])

    return {
        vehiculos, loading, error, fetchVehiculos}
}

export const useVehiculosDisponibles = ({inicio, fin})=>{
    const [vehiculosDisponibles, setVehiculos] = useState([])
    const [loading, setLoading] = useState(false)
    const [error, setError] = useState(null)


    const fetchVehiculosDisponibles = useCallback(async ()=> {
        setLoading(true)
        setError(null)
        try{
            const data = await vehiculosService.getVehiculosDisponibles(inicio, fin);
            setVehiculos(data);
            console.log("Hook de vehiculos disponibles obtuvo correctamente la info")
        }
        catch(e){
            setError(e)
            console.error('Error al carga los vehiculos', e.message)    
        }
        finally{
            setLoading(false)
        }
    }, [inicio, fin])

    useEffect(()=>{
        fetchVehiculosDisponibles();

    },[fetchVehiculosDisponibles])

    return {
        vehiculosDisponibles, loading, error, fetchVehiculosDisponibles}
}
