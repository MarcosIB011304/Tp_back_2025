from fastapi import APIRouter, Depends, HTTPException, status
from sqlalchemy.orm import Session
from sqlalchemy import select
from app.deps import get_db
from app.models.danio import Danio
from app.schemas.danio import DanioOut, DanioCreate

router = APIRouter(prefix="/danios", tags=["Daños"])

@router.get("/", response_model=list[DanioOut])
def obtener_danios(db: Session = Depends(get_db)):
    stmt = select(Danio).order_by(Danio.id)
    return db.execute(stmt).scalars().all()

@router.post("/", response_model=DanioOut)
def crear_danio(payload: DanioCreate, db: Session = Depends(get_db)):
    obj = Danio(
        descripcion=payload.descripcion,
        fechaDanio=payload.fechaDanio,
        costo=payload.costo,
        alquiler_id=payload.alquiler_id
    )
    db.add(obj)
    db.commit()
    db.refresh(obj)
    return obj
