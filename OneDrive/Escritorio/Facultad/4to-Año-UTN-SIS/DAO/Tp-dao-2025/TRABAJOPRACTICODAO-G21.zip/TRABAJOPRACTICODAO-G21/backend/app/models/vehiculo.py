from sqlalchemy import Boolean, Integer, String, ForeignKey, Float
from sqlalchemy.orm import Mapped,Session,selectinload, mapped_column, relationship
from datetime import date
from app.db import Base
from app.secondary import rangos_se_solapan

class Vehiculo(Base):
    __tablename__ = "Vehiculo"
    patente: Mapped[str]= mapped_column(String, primary_key=True, index=True)
    añoModelo: Mapped[int] =mapped_column(Integer, unique=False)
    añoIngreso: Mapped[int] =mapped_column(Integer, unique=False)
    kilometros: Mapped[float]= mapped_column(Float, default=0)
    precioPorDia: Mapped[float] = mapped_column(Float, default=0)
    color: Mapped[str] = mapped_column(String)
    disponibleHoy:Mapped[bool] = mapped_column(Boolean, default=True) #Refinar calculo de disponiblidad en la siguiente

    modelo_id: Mapped[int] = mapped_column(ForeignKey("Modelo.id"))

    modelo: Mapped["Modelo"] = relationship(
        back_populates="vehiculos"
    )
    alquileres: Mapped[list["Alquiler"]] = relationship(
        back_populates="vehiculo",
        cascade="all"
    )
    def esta_disponible_en_rango(self, inicio: date, fin: date) -> bool:
        for alquiler in self.alquileres:
            print("Alquileres del vehículo", alquiler)
            if rangos_se_solapan(inicio, fin, alquiler.fechaDelnicio, alquiler.fechaFin):
                return False
        return True
    
    def actualizar_disponible_hoy(self, hoy: date |None = None) -> None:
        if hoy is None:
            hoy = date.today()

        self.disponibleHoy = self.esta_disponible_en_rango(hoy, hoy)







def actualizar_disponibilidad_vehiculos_hoy(db:Session, hoy: date | None= None)-> list [Vehiculo]:
    if hoy is None:
        hoy = date.today()
    
    vehiculos = (db.query(Vehiculo)
                 .options(selectinload(Vehiculo.alquileres))
                 .all())
    for vehiculo in vehiculos:
        vehiculo.actualizar_disponible_hoy(hoy)
    db.commit()
    return vehiculos