from datetime import date

def rangos_se_solapan(inicio1: date, fin1:date, inicio2:date, fin2:date) -> bool:
    return not (fin1 < inicio2 or inicio1 > fin2)