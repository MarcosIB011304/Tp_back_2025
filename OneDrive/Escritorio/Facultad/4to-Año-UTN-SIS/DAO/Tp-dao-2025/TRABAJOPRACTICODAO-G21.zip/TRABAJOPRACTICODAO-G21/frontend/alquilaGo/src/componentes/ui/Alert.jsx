export default function Alert({ type = "error", message }) {
  return (
    <div
      className={`alert ${type}`}
      style={{
        padding: "12px 16px",
        borderRadius: 6,
        marginBottom: 16,
        background: type === "error" ? "#ffe0e0" : "#e0ffe4",
        border: `1px solid ${type === "error" ? "#ff5b5b" : "#3ac47d"}`,
        color: type === "error" ? "#a80000" : "#0f7a38",
        fontWeight: 500,
      }}
    >
      {message}
    </div>
  );
}