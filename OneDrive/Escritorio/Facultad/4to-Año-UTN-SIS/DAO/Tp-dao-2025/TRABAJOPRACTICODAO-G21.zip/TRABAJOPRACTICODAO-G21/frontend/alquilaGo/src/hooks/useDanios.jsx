import { useCallback, useEffect, useState } from "react";
import daniosService from "../services/danioService";

export const useDanios = () => {
  const [danios, setDanios] = useState([]);
  const [loading, setLoading] = useState(false);
  const [error, setError] = useState(null);

  const fetchDanios = useCallback(async () => {
    setLoading(true);
    setError(null);
    try {
      const data = await daniosService.getDanios();
      setDanios(data);
    } catch (e) {
      setError(e);
      console.error("Error al cargar daños", e.message);
    } finally {
      setLoading(false);
    }
  }, []);

  useEffect(() => {
    fetchDanios();
  }, [fetchDanios]);

  return { danios, loading, error, fetchDanios };
};
