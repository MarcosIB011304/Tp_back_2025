import React, { useState } from 'react';
import Modal from '../../componentes/ui/Modal';
import FormInput from '../../componentes/form/FormInput';
import { useClientes } from '../../hooks/UseClientes'
import Loading from '../../componentes/ui/Loading';

const formInicial = {
  dni: "",
  nombre: "",
  apellido: "",
  email: "",
  telefono: "",
  direccion: "",
};

export default function Clientes() {
  const [showModal, setShowModal] = useState(false);
  const [selectedClient, setSelectedClient] = useState(null);
  const [searchTerm, setSearchTerm] = useState('');
  const { clientes, isLoading, error, agregarCliente, editarCliente, borrarCliente } = useClientes();
  const [formData, setFormData] = useState(formInicial);
  const [formError, setFormError] = useState(null);
  const [isEditing, setIsEditing] = useState(false);
  const [alquileresCliente, setAlquileresCliente] = useState([]);
  const [cargandoAlquileres, setCargandoAlquileres] = useState(false);
  const [errorAlquileres, setErrorAlquileres] = useState(null);

  const openModal = () => {
    setFormData(formInicial);
    setFormError(null);
    setShowModal(true);
  };

  const closeModal = () => {
    setShowModal(false);
    setIsEditing(false);
    setFormData(formInicial);
    };

  const handleChange = (e) => {
    const { name, value } = e.target;

    setFormData((datos) => ({
      ...datos,
      [name]: value,
    }));
  };

  const iniciarEdicion = (cliente) => {
  setIsEditing(true);
  setFormError(null);

  setFormData({
    dni: cliente.dni,
    nombre: cliente.nombre,
    apellido: cliente.apellido,
    email: cliente.email,
    telefono: cliente.telefono,
    direccion: cliente.direccion || "",
  });

  setSelectedClient(null);   // cerramos modal detalle
  setShowModal(true);        // abrimos modal de formulario
};
  const handleSubmit = async () => {
  if (!formData.nombre.trim()) return setFormError("El nombre es obligatorio.");
  if (!formData.apellido.trim()) return setFormError("El apellido es obligatorio.");

  if (!/^\d+$/.test(formData.dni)) return setFormError("El DNI debe contener solo números.");
  if (!/^\d+$/.test(formData.telefono)) return setFormError("El teléfono debe contener solo números.");

  if (!/\S+@\S+\.\S+/.test(formData.email))
    return setFormError("El email no tiene un formato válido.");

  try {
    setFormError(null);

    if (isEditing) {
      // 🔹 EDITAR
      await editarCliente(formData.dni, formData);
    } else {
      // 🔹 CREAR
      await agregarCliente(formData);
    }

    // cierre
    closeModal();
    setFormData(formInicial);
    setIsEditing(false);

  } catch (err) {
    const detalle = err.response?.data?.detail;
    setFormError(detalle || "Error al guardar el cliente");
  }
};

const eliminarCliente = async (cliente) => {
  if (!window.confirm(`¿Eliminar cliente ${cliente.nombre}?`)) return;

  try {
    await borrarCliente(cliente.dni);
    setSelectedClient(null);
  } catch (err) {
    alert("Error al borrar el cliente");
  }
};

const cargarAlquileresDeCliente = async (clienteId) => {
  try {
    setCargandoAlquileres(true);
    setErrorAlquileres(null);

    const data = await obtenerAlquileres(clienteId);
    setAlquileresCliente(data); // <<--- los guardás para mostrarlos

  } catch (err) {
    setErrorAlquileres("No se pudieron cargar los alquileres");
  } finally {
    setCargandoAlquileres(false);
  }
};


  if (isLoading) return <Loading />;

  if (error) {
    return (
      <div className="error-mensaje">
        Error al cargar clientes: {error.message}
      </div>
    );
  }

  return (
    <div>
      <div className="card-header">
        <h1 className="card-title">Clientes</h1>
        <button className="btn btn-primary" onClick={openModal}>➕ Agregar Cliente</button>
      </div>

      <div className="filters-container">
        <div className="form-group" style={{ marginBottom: 0 }}>
          <input
            type="text"
            className="form-input"
            placeholder="🔍 Buscar por nombre o DNI..."
            value={searchTerm}
            onChange={(e) => setSearchTerm(e.target.value)}
          />
        </div>
      </div>

            <div className="card">
        <div className="table-container">
          <table className="table">
            <thead>
              <tr><th>Nombre</th><th>DNI</th><th>Email</th><th>Teléfono</th><th>Alquileres</th><th>Acciones</th></tr>
            </thead>
            <tbody>
              {clientes.map(c => (
                <tr key={c.dni}>
                  <td>{c.nombre}</td><td>{c.dni}</td><td>{c.email}</td><td>{c.telefono}</td>
                  <td><span className="badge badge-info">{7}</span></td>
                  <td>
                    <button className="btn btn-sm btn-primary" onClick={() => setSelectedClient(c)}>Ver Detalle</button>
                  </td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>
      </div>

      {/* MODAL AGREGAR CLIENTE */}
      <Modal
        isOpen={showModal}
        onClose={closeModal}
        title="Agregar Cliente"
        footer={
          <>
            <button className="btn btn-secondary" onClick={closeModal}>
              Cancelar
            </button>
            <button className="btn btn-success" onClick={handleSubmit}>
              Guardar
            </button>
          </>
        }
      >
        {formError && (
          <div className="error-mensaje" style={{ color: "red", marginBottom: 12 }}>
            {formError}
          </div>
        )}

        <FormInput label="Nombre" name="nombre" value={formData.nombre} onChange={handleChange} required />
        <FormInput label="Apellido" name="apellido" value={formData.apellido} onChange={handleChange} required />

        <FormInput
          label="DNI"
          type="number"
          name="dni"
          placeholder="12345678"
          value={formData.dni}
          onChange={handleChange}
          required
        />

        <div className="form-row">
          <FormInput label="Email" type="email" name="email" value={formData.email} onChange={handleChange} required />
          <FormInput label="Teléfono" type="number" name="telefono" value={formData.telefono} onChange={handleChange} required />
        </div>

        <FormInput
          label="Dirección"
          name="direccion"
          placeholder="Calle 123"
          value={formData.direccion}
          onChange={handleChange}
        />
      </Modal>

      <Modal
        isOpen={!!selectedClient}
        onClose={() => setSelectedClient(null)}
        title={`Detalle de Cliente: ${selectedClient?.nombre || ''}`}
        footer={ <div style={{ display: "flex", gap: "10px", justifyContent: "flex-end" }}>
      <button
        className="btn btn-danger"
        onClick={() => eliminarCliente(selectedClient)}>
        Eliminar
      </button>

      <button
        className="btn btn-primary"
        onClick={() => iniciarEdicion(selectedClient)}>
        Editar
      </button>

      <button
        className="btn btn-secondary"
        onClick={() => setSelectedClient(null)}>
        Volver
      </button>
    </div>}>
{selectedClient && (
  <>
    <div className="detail-grid">
      <div className="detail-item"><div className="detail-label">Nombre</div><div className="detail-value">{selectedClient.nombre}</div></div>
      <div className="detail-item"><div className="detail-label">Apellido</div><div className="detail-value">{selectedClient.apellido}</div></div>
      <div className="detail-item"><div className="detail-label">DNI</div><div className="detail-value">{selectedClient.dni}</div></div>
      <div className="detail-item"><div className="detail-label">Email</div><div className="detail-value">{selectedClient.email}</div></div>
      <div className="detail-item"><div className="detail-label">Teléfono</div><div className="detail-value">{selectedClient.telefono}</div></div>
      <div className="detail-item"><div className="detail-label">Alquileres Totales</div><div className="detail-value">{alquileresCliente.length}</div></div>
    </div>

    <h3 style={{ marginTop: 24, marginBottom: 16, color: 'var(--primary-blue)' }}>Historial de Alquileres</h3>
    <table>
      <thead>
          <th>Fecha Inicio</th>
          <th>Fecha Fin</th>
          <th>Patente Vehículo</th>
          <th>DNI Empleado</th>
      </thead>
      <tbody>
        {alquileresCliente && alquileresCliente.length > 0 ? (
          alquileresCliente.map((a) => (
            <tr key={a.id}>
              <td>{a.fechaInicio}</td>
              <td>{a.fechaFin}</td>
              <td>{a.vehiculoPatente}</td>
              <td>{a.empleadoDni}</td>
            </tr>
          ))
        ) : (
          <tr>
            <td colSpan="4" style={{ textAlign: 'center', padding: 12 }}>
              No tiene alquileres registrados
            </td>
          </tr>
        )}
      </tbody>
    </table>
  </>
)}

      </Modal>
    </div>
  );
}
