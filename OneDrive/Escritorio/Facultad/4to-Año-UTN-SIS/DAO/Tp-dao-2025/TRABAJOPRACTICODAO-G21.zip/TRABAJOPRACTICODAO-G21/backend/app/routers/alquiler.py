from fastapi import APIRouter, Depends, status, HTTPException
from sqlalchemy import select, update
from sqlalchemy.orm import Session
from app.deps import get_db
from app.models.alquiler import Alquiler
from app.models.vehiculo import Vehiculo
from app.schemas.alquiler import AlquilerBase, AlquilerCreate, AlquilerOut
from app.models.danio import Danio
from app.schemas.danio import DanioOut, DanioCreate
from datetime import date

router = APIRouter(prefix="/alquileres", tags=["Alquiler"])

@router.get("/", response_model=list[AlquilerOut])
def obtener_alquileres(db: Session = Depends(get_db)):
    stmt = select(Alquiler).order_by(Alquiler.fechaDeGestion.desc())
    rows= db.execute(stmt).scalars().all()

    return rows

@router.post("/", response_model=AlquilerOut)
def crear_alquiler(payload: AlquilerCreate, db: Session = Depends(get_db)):
    obj = Alquiler()
    obj.cliente_dni = payload.cliente_dni
    obj.empleado_dni = payload.empleado_dni
    obj.fechaDeGestion = payload.fechaDeGestion
    obj.fechaDelnicio = payload.fechaDelnicio
    obj.fechaFin = payload.fechaFin
    obj.vehiculo_patente = payload.vehiculo_patente
    obj.montoAlquiler = payload.montoAlquiler
    
    db.add(obj)
    try:
        db.commit()
        
    except Exception  as e:
        db.rollback()
        raise HTTPException(status_code=status.HTTP_400_BAD_REQUEST, detail=f"Error al intentar crear el alquiler {e}")
    db.refresh(obj)
    return obj



@router.get('/finalizados', response_model=list[AlquilerOut])
def obtenerAlquileresFinalizados(db:Session = Depends(get_db)):
    hoy = date.today()
    stmt = select(Alquiler).where(Alquiler.fechaFin < hoy)
    rows= db.execute(stmt).scalars().all()
    return rows

@router.get('/{id}', response_model=AlquilerOut)
def obtenerAlquilerPorId(id: int, db:Session = Depends(get_db)):
    obj = db.get(Alquiler, id)
    if not obj:
        raise HTTPException(status_code=status.HTTP_404_NOT_FOUND)
    return obj
@router.get('/cliente/{dni}', response_model=list[AlquilerOut])
def obtenerAlquilerDeCliente(dni: int,db:Session=Depends(get_db)):
    stmt = select(Alquiler).where(Alquiler.cliente_dni == dni)
    rows = db.execute(stmt).scalars().all()
    return rows

@router.patch("/finalizar/{alquiler_id}", response_model=AlquilerOut)
def finalizar_alquiler(alquiler_id: int, db: Session = Depends(get_db)):
    fecha_hoy_date = date.today()

    try:
        
        affected = db.query(Alquiler).filter(Alquiler.id == alquiler_id).update(
            {Alquiler.fechaFin: fecha_hoy_date}
        )
        if affected == 0:
            # No se actualizó ninguna fila, podría ser porque el id no existe
            raise HTTPException(status_code=status.HTTP_404_NOT_FOUND, detail="Alquiler no encontrado")
        db.commit()
        # Traemos la entidad actualizada para devolverla
        obj_actualizado = db.get(Alquiler, alquiler_id)
        return obj_actualizado
    except Exception as e:
        db.rollback()
        # Si la columna fechaFin es DateTime, descomenta la variante datetime y prueba:
        # edita la excepción para intentar con DateTime si es necesario
        raise HTTPException(status_code=status.HTTP_500_INTERNAL_SERVER_ERROR, detail=f"Error al finalizar el alquiler: {e}")