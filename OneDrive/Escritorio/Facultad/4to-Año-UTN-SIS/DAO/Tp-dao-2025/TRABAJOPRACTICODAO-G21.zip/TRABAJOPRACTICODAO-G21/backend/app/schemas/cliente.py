from typing import Optional
from datetime import date
from pydantic import Field, BaseModel
from pydantic import BaseModel, EmailStr, Field, ConfigDict  

##CLIENTE
class ClienteBase(BaseModel):
    nombre: str = Field(..., min_length=1, max_length=80)
    apellido: str = Field(..., min_length=1, max_length=80)
    email: EmailStr
    telefono: Optional[str] = None

class ClienteCreate(ClienteBase):
    dni: int
    fechaAlta: str
class ClienteUpdate(BaseModel):
    nombre: Optional[str] = Field(None, min_length=1, max_length=80)
    apellido: Optional[str] = Field(None, min_length=1, max_length=80)
    email: Optional[EmailStr] = None
    telefono: Optional[str] = None

class ClienteOut(ClienteBase):
    dni: int
    fechaAlta: str
 #
    class Config:
        from_attributes = True  
class ClienteSimpleOut(ClienteBase):
    dni:int
    nombre: str
    apellido: str
    class Config:
        from_attributes = True



ClienteOut.model_rebuild()