
import { useState, useEffect, useCallback } from "react";
import { getClientes, createCliente, updateCliente, deleteCliente, getAlquileresDeCliente} from "../services/clientesService";

export function useClientes() {
  const [clientes, setClientes] = useState([]);
  const [isLoading, setIsLoading] = useState(true);
  const [error, setError] = useState(null);

  const fetchClientes = useCallback(async () => {
    try {
      setIsLoading(true);
      const data = await getClientes();
      setClientes(data);
      setError(null);
    } catch (err) {
      setError(err);
    } finally {
      setIsLoading(false);
    }
  }, []);

  useEffect(() => {
    fetchClientes();
  }, [fetchClientes]);

  const agregarCliente = async (clienteData) => {
    try {
      const nuevoCliente = await createCliente(clienteData);
      setClientes((clientesActuales) => [nuevoCliente, ...clientesActuales]);
    } catch (err) {
      console.error("Error al crear cliente:", err);
      throw err;
    }
  };
  const editarCliente = async (dni, data) => {
    try {
      const res = await updateCliente(dni, data);
      setClientes((list) => list.map((c) => (c.dni === dni ? res.data : c)));
      return res.data;
    } catch (err) {
      console.error('Error al editar cliente', err);
      throw err;
    }
};


const borrarCliente = async (dni) => {
    try {
      await deleteCliente(dni);
      setClientes((list) => list.filter((c) => c.dni !== dni));
    } catch (err) {
      console.error('Error al borrar cliente', err);
      throw err;
    }
};

const obtenerAlquileres = async (clienteId) => {
    try {
      const res = await getAlquileresDeCliente(clienteId);
      return res.data;
    } catch (err) {
      console.error('Error al obtener alquileres', err);
      throw err;
    }
};

  return { clientes, isLoading, error, agregarCliente, editarCliente, borrarCliente, obtenerAlquileres };
}