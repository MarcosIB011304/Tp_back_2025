import React, { useState } from 'react'
import Modal from '../../componentes/ui/Modal'
import FormInput from '../../componentes/form/FormInput'
import FormSelect from '../../componentes/form/FormSelect'
import { useVehiculos } from '../../hooks/UseVehiculos'
import useMarcas from '../../hooks/UseMarcas'
import useModelos from '../../hooks/UseModelos'
import vehiculosService from '../../services/vehiculosService'
import mYmService from '../../services/mYmService' // <- service marcas/modelos

export default function Vehiculos() {
  const [subView, setSubView] = useState('lista')
  const [showModal, setShowModal] = useState(false)

  const { vehiculos, loadingVehiculos, errorVehiculos, fetchVehiculos } = useVehiculos()
  const { marcas, loadingMarcas, errorMarcas, fetchMarcas } = useMarcas()
  const { modelos, loadingModelos, errorModelos, fetchModelos } = useModelos()

  const [marcaFiltrado, setMarcaFiltrado] = useState(null)

  const [nuevoVehiculo, setNuevoVehiculo] = useState({
    patente: '',
    añoModelo: '',
    añoIngreso: '2025',
    modelo_id: '',
    color: '',
    precioPorDia: '',
    kilometros: '',
    disponibleHoy: true
    
  })

  // Marca seleccionada en el alta de vehículo
  const [marcaTemp, setMarcaTemp] = useState(null)

  // Nueva marca (alta en subView === 'marcas')
  const [nuevaMarca, setNuevaMarca] = useState({
    nombre: ''
  })

  // Nuevo modelo (alta en subView === 'modelos')
  const [nuevoModelo, setNuevoModelo] = useState({
    nombre: '',
    marca_id: '',
    
  })

  const disponibilidadVehiculo = (v) => {
    if (v.disponibleHoy) {
      return (<td><span className="badge badge-success">Disponible</span></td>)
    }
    else {
      return (<td><span className="badge badge-danger">No Disponible</span></td>)
    }
  }

  const handleNuevoVehiculo = async (nv) => {
    try {
      const auto = await vehiculosService.crearVehiculo(nv)
      console.log("Vehiculo creado correctamente")
    }
    catch (error) {
      console.error("Error al crear el vehiculo", error.message)
    }
  }

  const handleGuardar = async () => {
    try {
      if (subView === 'lista') {
        // Alta de vehículo
        await handleNuevoVehiculo(nuevoVehiculo)
        await fetchVehiculos()
      } else if (subView === 'marcas') {
        // Alta de marca
        await mYmService.crearMarca(nuevaMarca)
        await fetchMarcas()
      } else if (subView === 'modelos') {
        // Alta de modelo
        await mYmService.crearModelo(nuevoModelo)
        await fetchModelos()
      }
      setShowModal(false)
    } catch (error) {
      console.error("Error al guardar", error.message)
    }
  }

  return (
    <div>
      <div className="card-header">
        <h1 className="card-title">Vehículos</h1>
        <div className="u-flex u-gap-12">
          <button
            className={`btn ${subView === 'lista' ? 'btn-primary' : 'btn-secondary'}`}
            onClick={() => setSubView('lista')}
          >
            Lista
          </button>
          <button
            className={`btn ${subView === 'marcas' ? 'btn-primary' : 'btn-secondary'}`}
            onClick={() => setSubView('marcas')}
          >
            Marcas
          </button>
          <button
            className={`btn ${subView === 'modelos' ? 'btn-primary' : 'btn-secondary'}`}
            onClick={() => setSubView('modelos')}
          >
            Modelos
          </button>
          <button className="btn btn-primary" onClick={() => setShowModal(true)}>➕ Agregar</button>
        </div>
      </div>

      {subView === 'lista' && (
        <div className="card">
          <div className="table-container">
            <table className="table">
              <thead>
                <tr><th>Marca</th><th>Modelo</th><th>Año</th><th>Color</th><th>Precio/Día</th><th>Estado</th><th>Acciones</th></tr>
              </thead>
              <tbody>
                {vehiculos.map((v) => (
                  <tr key={v.patente}>
                    <td>{v.modelo.marca_id}</td>
                    <td>{v.modelo.nombre}</td>
                    <td>{v.añoModelo}</td>
                    <td>{v.color}</td>
                    <td>{v.precioPorDia}</td>
                    {disponibilidadVehiculo(v)}
                    <td><button className="btn btn-sm btn-primary">Ver Detalle</button></td>
                  </tr>
                ))}

              </tbody>
            </table>
          </div>
        </div>
      )}

      {subView === 'marcas' && (
        <div className="card">
          <h3 style={{ marginBottom: 20, color: 'var(--primary-blue)' }}>Marcas de Vehículos</h3>
          {marcas.map((m) => (
            <div className="list-item" key={m.id}>
              <div className="list-item-content">
                <div className="list-item-title">{m.nombre}</div>
                <div className="list-item-subtitle">{m.modelos.length}</div>
              </div>
            </div>
          ))}
        </div>
      )}

      {subView === 'modelos' && (
        <div className="card">
          <h3 style={{ marginBottom: 20, color: 'var(--primary-blue)' }}>Modelos por Marca</h3>
          <FormSelect
            label="Seleccionar Marca"
            options={marcas.map((m) => ({ value: String(m.id), label: m.nombre }))}
            value={marcaFiltrado || ''}
            onChange={(val) => setMarcaFiltrado(val)}
          />
          <div style={{ marginTop: 20 }}>
            {modelos.map((m) => (
              <div className="list-item" key={m.id}>
                <div className="list-item-content">
                  <div className="list-item-title">{m.nombre}</div>
                  <div className="list-item-subtitle">{m.stock} unidades</div>
                </div>
              </div>
            ))}
          </div>
        </div>
      )}

      <Modal
        isOpen={showModal}
        onClose={() => setShowModal(false)}
        title={`Agregar ${subView === 'marcas' ? 'Marca' : subView === 'modelos' ? 'Modelo' : 'Vehículo'}`}
        footer={
          <>
            <button className="btn btn-secondary" onClick={() => setShowModal(false)}>Cancelar</button>
            <button className="btn btn-success" onClick={handleGuardar}>Guardar</button>
          </>
        }
      >
        {subView === 'lista' && (
          <>
            {/* MARCA: guarda el id, pero en marcaTemp guardamos el objeto completo */}
            <FormSelect
              label="Marca"
              options={marcas.map((m) => ({ value: String(m.id), label: m.nombre }))}
              value={marcaTemp ? String(marcaTemp.id) : ''}
              onChange={(val) => {
                const encontrada = marcas.find(m => String(m.id) === String(val))
                setMarcaTemp(encontrada || null)
                // al cambiar de marca, limpiamos el modelo seleccionado
                setNuevoVehiculo({ ...nuevoVehiculo, modelo_id: '' })
              }}
              required
            />

            {/* MODELO: opciones vienen de marcaTemp.modelos */}
            <FormSelect
              label="Modelo"
              options={
                marcaTemp && marcaTemp.modelos
                  ? marcaTemp.modelos.map((m) => ({ value: String(m.id), label: m.nombre }))
                  : []
              }
              value={nuevoVehiculo.modelo_id}
              onChange={(val) => setNuevoVehiculo({ ...nuevoVehiculo, modelo_id: val })}
              required
            />

            <div className="form-row">
              <FormInput
                label="Año"
                type="number"
                placeholder="2023"
                value={nuevoVehiculo.añoModelo}
                onChange={(val) => setNuevoVehiculo({ ...nuevoVehiculo, añoModelo: val })}
                required
              />
              <FormInput
                label="Color"
                placeholder="Blanco"
                required
                value={nuevoVehiculo.color}
                onChange={(val) => setNuevoVehiculo({ ...nuevoVehiculo, color: val })}
              />
              <FormInput
                label="Kilómetros"
                placeholder="0,1000,10000"
                type='number'
                required
                value={nuevoVehiculo.kilometros}
                onChange={(val) => setNuevoVehiculo({ ...nuevoVehiculo, kilometros: parseInt(val) })}
              />
            </div>
            <FormInput
              label="Precio por Día"
              type="number"
              placeholder="500"
              value={nuevoVehiculo.precioPorDia}
              onChange={(val) => setNuevoVehiculo({ ...nuevoVehiculo, precioPorDia: val })}
              required
            />
            <FormInput
              label="Patente"
              placeholder="ABC123"
              value={nuevoVehiculo.patente}
              onChange={(val) => setNuevoVehiculo({ ...nuevoVehiculo, patente: val })}
              required
            />
          </>
        )}

        {subView === 'marcas' && (
          <FormInput
            label="Nombre de la Marca"
            placeholder="Ej: Toyota"
            required
            value={nuevaMarca.nombre}
            onChange={(val) => setNuevaMarca({ ...nuevaMarca, nombre: val })}
          />
        )}

        {subView === 'modelos' && (
          <>
            <FormSelect
              label="Marca"
              options={marcas.map((m) => ({ value: String(m.id), label: m.nombre }))}
              value={nuevoModelo.marca_id}
              onChange={(val) => setNuevoModelo({ ...nuevoModelo, marca_id: val })}
              required
            />
            <FormInput
              label="Nombre del Modelo"
              placeholder="Ej: Corolla"
              required
              value={nuevoModelo.nombre}
              onChange={(val) => setNuevoModelo({ ...nuevoModelo, nombre: val })}
            />
            <FormSelect
              label="Tipo"
              options={[
                { value: 'sedan', label: 'Sedán' },
                { value: 'suv', label: 'SUV' },
                { value: 'pickup', label: 'Pickup' }
              ]}
              value={nuevoModelo.tipo}
              
              required
            />
          </>
        )}
      </Modal>
    </div>
  )
}
