from sqlalchemy import Column, Integer, String, Date, DateTime, ForeignKey, Float
from sqlalchemy.orm import mapped_column, Mapped, relationship
from app.db import Base, engine
from datetime import date

class Cobro(Base):
    __tablename__= "Cobro"
    nroCobro: Mapped[int] = mapped_column(primary_key=True, index=True)
    monto : Mapped[float] = mapped_column(Float)
    formaDePago: Mapped[str] =mapped_column(String)
    fechaPago: Mapped[date] = mapped_column(Date)
    desc: Mapped[str] = mapped_column(String)
    
    alquiler_id: Mapped[int] = mapped_column(ForeignKey("Alquiler.id"), unique=False)

    alquiler: Mapped["Alquiler"] =  relationship(
        back_populates="cobros"
    )