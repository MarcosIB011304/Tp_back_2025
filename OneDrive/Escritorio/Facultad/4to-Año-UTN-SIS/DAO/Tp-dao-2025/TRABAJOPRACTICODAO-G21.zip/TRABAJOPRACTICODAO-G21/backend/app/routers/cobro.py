from fastapi import APIRouter, Depends, HTTPException, status
from sqlalchemy import or_, exc, select
from sqlalchemy.orm import Session
from app.deps import get_db
from app.models.cobro import Cobro
from app.schemas.cobro import CobroCreate, CobroOut

router = APIRouter(prefix="/cobros", tags=["Cobros"])

@router.post("", response_model=CobroOut)
def crear_cobro(payload: CobroCreate, db: Session = Depends(get_db)):
    cobro = Cobro(
        alquiler_id=payload.alquiler_id,
        monto = payload.monto,
        formaDePago= payload.formaDePago,
        fechaPago = payload.fechaPago,
        desc = payload.desc
    )
    db.add(cobro)
    try:
        db.commit()
    except Exception as e:
        db.rollback()
        raise HTTPException(
            status_code=status.HTTP_404_NOT_FOUND,
            detail="Error al cargar el cobro",
        )
    db.refresh(cobro)
    return cobro

@router.get("", response_model=list[CobroOut])
def obtener_cobros(db: Session= Depends(get_db)):
    stmt = select(Cobro).order_by(Cobro.nroCobro)
    rows = db.execute(stmt).scalars().all()

    return rows