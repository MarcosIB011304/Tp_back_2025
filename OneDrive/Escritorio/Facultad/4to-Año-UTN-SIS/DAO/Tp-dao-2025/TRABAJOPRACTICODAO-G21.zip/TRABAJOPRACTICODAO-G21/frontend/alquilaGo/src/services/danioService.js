import apiClient from "./apiClient";

const getDanios = async () => {
  const response = await apiClient.get("/danios");
  return response.data;
};

const crearDanio = async (nuevo) => {
  const response = await apiClient.post("/danios", nuevo);
  return response.data;
};

export default { getDanios, crearDanio };
