import alquileresService from "../services/alquileresService";
import cobrosService from "../services/cobroService";
import vehiculosService from "../services/vehiculosService";


const transaccionNuevoAlquiler = async(data)=>{
    const fecha = new Date()
    const dia = fecha.toLocaleDateString(undefined, { day: '2-digit' });
    const hoy = `${fecha.getFullYear()}-${(fecha.getMonth())+ 1}-${dia}`
    const nuevoAlquiler= {cliente_dni: data.clienteDni, empleado_dni: 24094089, fechaFin: data.fechaFin,  fechaDelnicio: data.fechaInicio, vehiculo_patente: data.vehiculoPatente, montoAlquiler: data.montoAlquiler, fechaDeGestion:hoy}
    
    try{
        const alquiler = await alquileresService.crearAlquiler(nuevoAlquiler)
        console.log("Alquiler creado con éxito")
        if (alquiler.id != null){
            console.log("Alquiler creado con éxito")
            const nuevoCobro = {alquiler_id: alquiler.id, monto: (data.montoAlquiler * 0.4).toFixed(2), formaDePago: data.metodoPago, fechaPago: hoy}
            try{
                const data = await cobrosService.nuevoCobro(nuevoCobro)
                if (data.id){
                    console.log("Cobro registrado con éxito: ", data.montoCobrado)
                }
                return true
            }
            catch(error){
                console.error(`Ocurrió un error al cargar el cobro del alquiler con id${nuevoCobro.alquiler_id}, ${error.message}`)
                return false
            }
        }
        
    }
    catch(error){
        console.error(`Ocurrió un error al hacer la transacción del alquiler ${error.message}`)
        return false
    }
}

const transaccionFinalizarAlquiler = async(idAlquiler, dataVehiculo)=>{
    try{
        const respose = await alquileresService.finalizarAlquiler(idAlquiler)
        console.log("Alquiler Finalizado Correctamente", response.fechaFin)
        try{
            const responseAuto = await vehiculosService.actualizarKilometrosVehiculo(dataVehiculo)
            console.log("Vehiculo Actualizado Correctamente, nuevo kilometraje: ", responseAuto.kilometros)

        }
        catch(e){
            console.error("Ocurrió un error al actualizar el kilometraje del vehiculo", error.message)
        }
    }
    catch(e){
        console.error("Ocurrió un error al finalizar el alquiler", error.message)
    }
}


const auxiliarNuevoAlquiler = {transaccionNuevoAlquiler, transaccionFinalizarAlquiler}

export default auxiliarNuevoAlquiler