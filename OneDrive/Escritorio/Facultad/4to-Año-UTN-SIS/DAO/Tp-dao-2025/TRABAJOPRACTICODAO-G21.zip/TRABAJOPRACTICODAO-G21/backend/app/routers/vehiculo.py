from fastapi import APIRouter, Depends, HTTPException, status
from sqlalchemy import select
from sqlalchemy.orm import Session, selectinload
from app.deps import get_db
from app.models.vehiculo import Vehiculo, actualizar_disponibilidad_vehiculos_hoy
from app.schemas.vehiculo import VehiculoBase, VehiculoCreate, VehiculoOut
from datetime import date


router = APIRouter(prefix="/vehiculos", tags=["Vehiculos"])

@router.get("/", response_model=list[VehiculoOut])
def obtener_vehiculos(db: Session= Depends(get_db)):
    hoy = date.today()
    vehiculos = actualizar_disponibilidad_vehiculos_hoy(db, hoy)
    return vehiculos

@router.get("/disponiblesEnRango", response_model=list[VehiculoOut])
def obtener_vehiculos_disponibles(fechaInicio: date, fechaFin: date, db: Session= Depends(get_db)):
    vehiculos = (
        db.query(Vehiculo)
        .options(selectinload(Vehiculo.alquileres))
        .all()
    )
    vehiculos_disponibles = [ v for v in vehiculos if v.esta_disponible_en_rango(fechaInicio, fechaFin)]

    return vehiculos_disponibles


@router.get("/{patente}", response_model=VehiculoOut)
def obtener_vehiculo_patente(patente:str, db: Session= Depends(get_db)):
    obj = db.get(Vehiculo,patente)
    if not obj:
        raise HTTPException(status_code=status.HTTP_404_NOT_FOUND)
    return obj

@router.post("/", response_model=VehiculoOut)
def crear_vehiculo(payload:VehiculoCreate, db: Session =  Depends(get_db)):
    obj= Vehiculo()
    obj.patente = payload.patente
    obj.añoIngreso = payload.añoIngreso
    obj.añoModelo = payload.añoModelo
    obj.color = payload.color
    obj.disponibleHoy = payload.disponibleHoy
    obj.kilometros = payload.kilometros
    obj.modelo_id = payload.modelo_id
    obj.precioPorDia = payload.precioPorDia

    db.add(obj)
    try:
        db.commit()
    except Exception as e:
        db.rollback()
        raise HTTPException(status_code=status.HTTP_400_BAD_REQUEST,detail=f"Error al agregar el vehículo {e}")
    db.refresh(obj)
    return obj


@router.patch("/{patente}/sumar_kilometros", response_model=VehiculoOut)
def sumar_kilometros(patente: str, kms_recorridos: int, db: Session = Depends(get_db)):
    """
    Suma 'kms_recorridos' a los kilómetros actuales del Vehículo identificado por 'patente'.
    """
    if kms_recorridos <= 0:
        raise HTTPException(
            status_code=status.HTTP_400_BAD_REQUEST,
            detail="La cantidad de kilómetros a sumar debe ser mayor que cero"
        )

    # Intentar obtener el vehículo existente
    vehiculo = db.get(Vehiculo, patente)
    if not vehiculo:
        raise HTTPException(status_code=status.HTTP_404_NOT_FOUND, detail="Vehículo no encontrado")

    # Supongamos que el campo es 'kilometros' (según tu modelo)
    try:
        nuevo_km = vehiculo.kilometros + kms_recorridos
        vehiculo.kilometros = nuevo_km

        db.commit()
        db.refresh(vehiculo)
        return vehiculo
    except Exception as e:
        db.rollback()
        raise HTTPException(
            status_code=status.HTTP_500_INTERNAL_SERVER_ERROR,
            detail=f"Error al actualizar los kilómetros: {e}"
        )   