import React from 'react'
import { useNavigate } from 'react-router-dom'
import { useAlquileres } from '../../hooks/UseAlquileres'
import { useState, useEffect } from 'react'
import FormInput from '../../componentes/form/FormInput'
import FormSelect from '../../componentes/form/FormSelect'
import Modal from '../../componentes/ui/Modal'
import alquileresService from '../../services/alquileresService'
import cobrosService from '../../services/cobroService'

export default function Alquileres() {

    const navigate = useNavigate()
    const [showModal, setShowModal] = useState(false)
    const [selectedAlquiler, setSelectedAlquiler] = useState(null)
    const { alquileres, loadingAlquiler, errorAlquiler, fetchAlquileres } = useAlquileres()
    const [alquilerSeleccionado, setAlquilerSeleccionado] = useState([])
    const [codigoIngresado, setCodigoIngresado] = useState('')
    const [loading, setLoading] = useState(false)
    const [showPaymentModal, setShowPaymentModal] = useState(false)
    const codigoSucursal = '12fg354'
    const [cobrar, setCobrar] = useState(false)
    const estadoOptions = [
        { value: 'todos',      label: 'Todos',          className: 'badge badge-info' },
        { value: 'Reservado',  label: 'Solo reservados', className: 'badge badge-warning' },
        { value: 'En Curso',   label: 'Solo en curso',   className: 'badge badge-success' },
        { value: 'Finalizado', label: 'Solo finalizados', className: 'badge badge-danger' },
      ]

    const [actVehiculo, setActVehiculo] = useState({patente:'', kilometrosRecorridos: 0})
    // Filtros
    const [filtros, setFiltros] = useState({
      dni: '',
      patente: '',
      fechaInicio: '',
      fechaFin: '',
      estado: 'todos',
    })

    const [formCobro, setFormCobro] = useState({
      alquiler_id: '',
      fechaPago: '',
      formaDePago: '',
      monto: '',
      desc: ''
    })

    const fecha = new Date()
    const dia = fecha.toLocaleDateString(undefined, { day: '2-digit' });
    const hoy = `${fecha.getFullYear()}-${(fecha.getMonth()) + 1}-${dia}`

    // Mantener el selectedAlquiler sincronizado cuando se refrescan los alquileres
    useEffect(() => {
      if (selectedAlquiler) {
        const actualizado = alquileres.find(a => a.id === selectedAlquiler.id)
        if (actualizado) {
          setSelectedAlquiler(actualizado)
        }
      }
    }, [alquileres, selectedAlquiler])

    const handleCerrarDetalle = () => {
      setSelectedAlquiler(null)
      setCobrar(false)
      setShowPaymentModal(false)
      setFormCobro({
        alquiler_id: '',
        fechaPago: '',
        formaDePago: '',
        monto: '',
        desc: ''
      })
      setCodigoIngresado('')
    }

    const handleFinalizarPago = async () => {
      setLoading(true)
      setTimeout(async () => {
        try {
          const cargaDatos = await cobrosService.nuevoCobro(formCobro)
          if (cargaDatos) {
            // Refrescar alquileres para que se actualicen los cobros
            await fetchAlquileres()
            setLoading(false)
            setShowPaymentModal(false)
            alert('¡Cobro Añadido al alquiler')
            // Limpiar campos del formulario manteniendo el alquiler_id
            setFormCobro(prev => ({
              ...prev,
              fechaPago: '',
              formaDePago: '',
              monto: '',
              desc: ''
            }))
            setCodigoIngresado('')
            setCobrar(false)
          }
          else {
            setLoading(false)
            setShowPaymentModal(false)
            alert('Error al registrar el cobro.')
          }
        }
        catch (error) {
          console.error("ERROR AL REGISTRAR EL PAGO", error.message)
          setLoading(false)
        }

      })
    }

    const estaFinalizado= (alquiler)=>{
      
      const hoy = new Date()
      const inicio = new Date(alquiler.fechaDelnicio)
      const fin = new Date(alquiler.fechaFin)

      return (hoy > fin)
    }

    const EstadoEtiqueta = (alquiler) => {
      const hoy = new Date()
      const inicio = new Date(alquiler.fechaDelnicio);
      const fin = new Date(alquiler.fechaFin);

      let texto;
      let clase;

      if (inicio > hoy) {
        texto = 'Reservado';
        clase = 'badge badge-warning';
      } else if (fin > hoy) {
        texto = 'En Curso';
        clase = 'badge badge-success';
      } else {
        texto = 'Finalizado';
        clase = 'badge badge-danger';
      }
      return { clase, texto };
    }

    // Aplicar filtros sobre la lista de alquileres
    const alquileresFiltrados = alquileres.filter((alquiler) => {
      if (filtros.dni && !String(alquiler.cliente_dni).includes(filtros.dni)) {
        return false
      }
      if (filtros.patente && !String(alquiler.vehiculo_patente).toLowerCase().includes(String(filtros.patente).toLowerCase())) {
        return false
      }
      if (filtros.fechaInicio && alquiler.fechaDelnicio !== filtros.fechaInicio) {
        return false
      }
      if (filtros.fechaFin && alquiler.fechaFin !== filtros.fechaFin) {
        return false
      }
      if (filtros.estado && filtros.estado !== 'todos') {
        const { texto } = EstadoEtiqueta(alquiler)
        if (texto !== filtros.estado) {
          return false
        }
      }
      return true
    })

    return (
      <div>
        <div className="card-header">
          <h1 className="card-title">Alquileres</h1>
          <button className="btn btn-primary" onClick={() => { navigate("/alquileres/new") }} >➕ Nuevo Alquiler</button>
        </div>

        <div className="card">

          {/* Filtros */}
          <div className="filters-container" style={{ padding: 16 }}>
            <div className="filters-grid">
              <div className="filters-grid">
                <FormInput
                  label="DNI Cliente"
                  placeholder="Buscar por DNI"
                  type="text"
                  value={filtros.dni}
                  onChange={(val) => setFiltros({ ...filtros, dni: val })}
                />
              </div>
              <div className="filters-grid">
                <FormInput
                  label="Patente"
                  placeholder="Buscar por patente"
                  type="text"
                  value={filtros.patente}
                  onChange={(val) => setFiltros({ ...filtros, patente: val })}
                />
              </div>
            </div>
            <div className="filters-grid" style={{ marginTop: 12 }}>
              <div className="filters-grid">
                <FormInput
                  label="Fecha de Inicio"
                  type="date"
                  value={filtros.fechaInicio}
                  onChange={(val) => setFiltros({ ...filtros, fechaInicio: val })}
                />
              </div>
              <div className="filters-grid">
                <FormInput
                  label="Fecha de Fin"
                  type="date"
                  value={filtros.fechaFin}
                  onChange={(val) => setFiltros({ ...filtros, fechaFin: val })}
                />
              </div>
              <div className="filters-grid">
                <div className="form-group">
                  <FormSelect label="Estado" options={estadoOptions} value={filtros.estado} onChange={(val) => setFiltros({ ...filtros, estado: val })} />
                </div>

              </div>
            </div>
          </div>

          <div className="table-container">
            <table className="table">
              <thead>
                <th>Estado</th><th>Dni Cliente</th><th>Patente</th><th>Fecha de Inicio</th><th>Fecha de Fin</th><th>Acciones</th>
              </thead>
              <tbody>
                {alquileresFiltrados.map((alquiler) => {
                  let { clase, texto } = EstadoEtiqueta(alquiler)
                  return (
                    <tr key={alquiler.id}>
                      <td><span className={clase}>{texto}</span></td>
                      <td>{alquiler.cliente_dni}</td>
                      <td>{alquiler.vehiculo_patente}</td>
                      <td>{alquiler.fechaDelnicio}</td>
                      <td>{alquiler.fechaFin}</td>
                      <td>
                        <button
                          className="btn btn-sm btn-primary"
                          onClick={() => {
                            setSelectedAlquiler(alquiler);
                            setFormCobro({
                              alquiler_id: alquiler.id,
                              fechaPago: '',
                              formaDePago: '',
                              monto: '',
                              desc: ''
                            })
                            setCodigoIngresado('')
                          }}
                        >
                          Ver Detalle
                        </button>
                      </td>
                    </tr>
                  )
                })}
              </tbody>
            </table>

            <Modal
              isOpen={!!selectedAlquiler}
              onClose={handleCerrarDetalle}
              title={`Detalle de Alquiler: ${selectedAlquiler?.id || ''}`}
              footer={<button className="btn btn-secondary" onClick={handleCerrarDetalle}>Volver</button>}
            >

              {selectedAlquiler && (
                <>
                  <div className="detail-grid">
                    <div className="detail-item"><div className="detail-label">Dni Cliente</div><div className="detail-value">{selectedAlquiler.cliente_dni}</div></div>
                    <div className="detail-item"><div className="detail-label">Fecha de Gestion</div><div className="detail-value">{selectedAlquiler.fechaDeGestion}</div></div>
                    <div className="detail-item"><div className="detail-label">Fecha de Inicio</div><div className="detail-value">{selectedAlquiler.fechaDelnicio}</div></div>
                    <div className="detail-item"><div className="detail-label">Fecha de Fin</div><div className="detail-value">{selectedAlquiler.fechaFin}</div></div>
                    <div className="detail-item"><div className="detail-label">Modelo</div><div className="detail-value">{selectedAlquiler.vehiculo.modelo_id}</div></div>
                    <div className="detail-item"><div className="detail-label">Color Vehiculo</div><div className="detail-value">{selectedAlquiler.vehiculo.color}</div></div>
                  </div>
                  <div className='card-header'>
                    <h3 style={{ marginTop: 24, marginBottom: 16, color: 'var(--primary-blue)' }}>
                      Cobros
                    </h3>
                    <button
                      className="btn btn-primary"
                      onClick={() => {
                        setCobrar(true)
                        setFormCobro(prev => ({
                          ...prev,
                          fechaPago: '',
                          formaDePago: '',
                          monto: '',
                          desc: ''
                        }))
                        setCodigoIngresado('')
                      }}
                    >
                      ➕ Añadir Cobro
                    </button>
                    {!estaFinalizado(selectedAlquiler) && 
                    <button className='btn btn-danger'>
                      Finalizar Alquiler
                    </button>}
                    
                  </div>
                  <div className="table-container">
                    <table className="table">
                      <thead>
                        <tr><th>Fecha Cobro</th><th>Tipo Cobro</th><th>Monto</th><th>Descripción</th></tr>
                      </thead>
                      <tbody>
                        {selectedAlquiler.cobros && selectedAlquiler.cobros.map((cobro) => (
                          <tr key={cobro.nroCobro}>
                            <td>{cobro.fechaPago}</td>
                            <td>{cobro.formaDePago}</td>
                            <td>${cobro.monto}</td>
                            <td>{cobro.desc}</td>
                          </tr>
                        ))}
                      </tbody>

                    </table>

                  </div>

                  <Modal
                    isOpen={!!cobrar}
                    onClose={() => {
                      setCobrar(false)
                      setFormCobro(prev => ({
                        ...prev,
                        fechaPago: '',
                        formaDePago: '',
                        monto: '',
                        desc: ''
                      }))
                      setCodigoIngresado('')
                    }}
                    title={`Registrar Nuevo Cobro para el alquiler`}
                    footer={
                      <button
                        className="btn btn-secondary"
                        onClick={() => {
                          setCobrar(false)
                          setFormCobro(prev => ({
                            ...prev,
                            fechaPago: '',
                            formaDePago: '',
                            monto: '',
                            desc: ''
                          }))
                          setCodigoIngresado('')
                        }}
                      >
                        Volver
                      </button>
                    }
                  >
                    <div>
                      <h3 style={{ marginBottom: 24, color: 'var(--primary-blue)' }}>Monto</h3>
                      <div style={{ padding: 20, background: 'var(--light-gray)', borderRadius: 8, marginBottom: 24 }}>
                        <FormInput
                          label="Monto a Cobrar"
                          placeholder="Ingrese el monto a cobrar"
                          type='number'
                          value={formCobro.monto}
                          onChange={(val) => setFormCobro(prev => ({ ...prev, monto: parseFloat(val) }))}
                          required={true}
                        />
                      </div>
                      <h3 style={{ marginBottom: 24, color: 'var(--primary-blue)' }}>Descripcion</h3>
                      <div style={{ padding: 20, background: 'var(--light-gray)', borderRadius: 8, marginBottom: 24 }}>
                        <FormInput
                          label="Descripción del cobro"
                          placeholder="Ingrese los motivos del nuevo cobro"
                          type='text'
                          value={formCobro.desc}
                          onChange={(val) => setFormCobro(prev => ({ ...prev, desc: val }))}
                          required={true}
                        />
                      </div>
                      <h3 style={{ marginBottom: 24, color: 'var(--primary-blue)' }}>Método de Pago</h3>
                      <div style={{ display: 'grid', gap: 16, marginBottom: 24 }}>
                        <div
                          className={`vehicle-card ${formCobro.formaDePago === 'efectivo' ? 'selected' : ''}`}
                          onClick={() => setFormCobro(prev => ({ ...prev, formaDePago: 'efectivo', fechaPago: hoy }))}
                        >
                          <h3>💵 Efectivo</h3>
                          <p style={{ color: 'var(--text-light)', marginTop: 8 }}>Pago en sucursal con código de validación</p>
                        </div>
                        <div
                          className={`vehicle-card ${formCobro.formaDePago === 'tarjeta' ? 'selected' : ''}`}
                          onClick={() => setFormCobro(prev => ({ ...prev, formaDePago: 'tarjeta', fechaPago: hoy }))}
                        >
                          <h3>💳 Tarjeta de Crédito</h3>
                          <p style={{ color: 'var(--text-light)', marginTop: 8 }}>Pago inmediato con tarjeta</p>
                        </div>
                      </div>

                      {formCobro.formaDePago === 'efectivo' && (
                        <div style={{ padding: 20, background: 'var(--light-gray)', borderRadius: 8, marginBottom: 24 }}>
                          <FormInput
                            label="Código de Validación"
                            placeholder="Ingrese el código de la sucursal"
                            type='text'
                            value={codigoIngresado}
                            onChange={(val) => setCodigoIngresado(val)}
                            required={true}
                          />
                        </div>
                      )}

                      <div className="u-flex u-gap-12">
                        <button
                          className="btn btn-secondary"
                          onClick={() => {
                            setCobrar(false)
                            setFormCobro(prev => ({
                              ...prev,
                              fechaPago: '',
                              formaDePago: '',
                              monto: '',
                              desc: ''
                            }))
                            setCodigoIngresado('')
                          }}
                        >
                          ← Cerrar
                        </button>
                        <button
                          className="btn btn-success"
                          onClick={() =>
                            formCobro.formaDePago === 'tarjeta'
                              ? setShowPaymentModal(true) // Lógica existente, no la toco
                              : codigoIngresado === codigoSucursal
                                ? handleFinalizarPago()
                                : alert("El codigo ingresado no es correcto")
                          }
                          disabled={!formCobro.formaDePago}
                        >
                          Confirmar Pago
                        </button>
                      </div>
                    </div>

                  </Modal>
                </>
              )}
            </Modal>
          </div>
        </div>
      </div>
    )
}
