import apiClient from "./apiClient";

const getVehiculos = async()=>{
    const response = await apiClient.get('/vehiculos')
    return response.data
}

const getVehiculosDisponibles = async(inicio, fin) =>{
    const response = await apiClient.get('/vehiculos/disponiblesEnRango',  {params: {fechaInicio:inicio, fechaFin:fin}})
    return response.data
}

const crearVehiculo = async(nuevoVehiculo)=>{
    const response = await apiClient.post('/vehiculos', nuevoVehiculo)
    return response.data
}

const actualizarKilometrosVehiculo = async(data)=>{
    const response = await apiClient.patch(`/vehiculos/${data.patente}/sumar_kilometros`, data.kilometrosRecorridos)
    return response.data
}


const vehiculosService = {getVehiculos, getVehiculosDisponibles, crearVehiculo, actualizarKilometrosVehiculo}

export default vehiculosService

