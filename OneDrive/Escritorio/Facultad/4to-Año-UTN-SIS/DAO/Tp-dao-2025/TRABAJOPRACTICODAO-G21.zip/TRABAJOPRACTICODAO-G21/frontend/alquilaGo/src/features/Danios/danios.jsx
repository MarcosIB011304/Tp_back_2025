import React, { useState } from "react";
import { useDanios } from "../../hooks/useDanios";
import Modal from "../../componentes/ui/Modal";
import { useNavigate } from 'react-router-dom'

export default function Danios() {
  
  const navigate = useNavigate()
  const { danios, loading, error } = useDanios();
  const [selected, setSelected] = useState(null);

  return (
    <div>
      <div className="card-header">
        <h1 className="card-title">Daños registrados</h1>
        <button className="btn btn-primary" onClick={()=>{navigate("/danios/new")}} >➕ Nuevo Daño</button>
      </div>
      

      <div className="card">
        <div className="table-container">
          <table className="table">
            <thead>
              <tr>
                <th>ID</th>
                <th>Descripción</th>
                <th>Fecha</th>
                <th>Costo</th>
                <th>ID Alquiler</th>
                <th>Acciones</th>
              </tr>
            </thead>

            <tbody>
              {danios.map(d => (
                <tr key={d.id}>
                  <td>{d.id}</td>
                  <td>{d.descripcion}</td>
                  <td>{d.fechaDanio}</td>
                  <td>${d.costo}</td>
                  <td>{d.alquiler_id}</td>
                  <td>
                    <button className="btn btn-sm btn-primary"
                      onClick={() => setSelected(d)}>
                      Ver Detalle
                    </button>
                  </td>
                </tr>
              ))}
            </tbody>
          </table>

          <Modal
            isOpen={!!selected}
            onClose={() => setSelected(null)}
            title={`Daño ID: ${selected?.id}`}
            footer={<button className="btn btn-secondary" onClick={() => setSelected(null)}>Cerrar</button>}
          >
            {selected && (
              <>
                <div className="detail-item">Descripción: {selected.descripcion}</div>
                <div className="detail-item">Fecha: {selected.fechaDaño}</div>
                <div className="detail-item">Costo: ${selected.costo}</div>
                <div className="detail-item">Alquiler: {selected.alquiler_id}</div>
              </>
            )}
          </Modal>
        </div>
      </div>
    </div>
  );
}
