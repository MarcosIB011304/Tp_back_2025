import { useState, useEffect } from "react";
import { useNavigate } from "react-router-dom";
import daniosService from "../../services/danioService";
import FormInput from "../../componentes/form/FormInput";
import FormSelect from "../../componentes/form/FormSelect";
import Loading from "../../componentes/ui/Loading";
import Alert from "../../componentes/ui/Alert";

function Steps({ steps, currentStep }) {
  return (
    <div className="steps-container">
      {steps.map((step, index) => (
        <div
          key={index}
          className={`step ${
            index === currentStep ? "active" : ""
          } ${index < currentStep ? "completed" : ""}`}
        >
          <div className="step-circle">
            {index < currentStep ? "✓" : index + 1}
          </div>
          <div className="step-label">{step}</div>
        </div>
      ))}
    </div>
  );
}

export default function CrearDanio() {
  const navigate = useNavigate();
  const [currentStep, setCurrentStep] = useState(0);
  const [loading, setLoading] = useState(false);
  const [errorMsg, setErrorMsg] = useState("");

  const [alquileres, setAlquileres] = useState([]);

  const hoy = new Date().toISOString().split("T")[0];

  const [formData, setFormData] = useState({
    descripcion: "",
    fechaDanio: "",
    costo: "",
    alquiler_id: "",
  });

  const steps = ["Datos del Daño", "Seleccionar Alquiler", "Confirmación"];

  // Cargar alquileres
  useEffect(() => {
    fetch("http://localhost:8000/alquileres")
      .then((res) => res.json())
      .then((data) => setAlquileres(data))
      .catch((err) => console.error("Error cargando alquileres", err));
  }, []);

  const handleNext = () => {
    // Validaciones del paso 1
    if (currentStep === 0) {
      if (formData.fechaDanio > hoy) {
        return setErrorMsg("La fecha del daño no puede ser futura.");
      }
      if (parseFloat(formData.costo) <= 0) {
        return setErrorMsg("El costo debe ser mayor a 0.");
      }
    }
    setErrorMsg("");
    setCurrentStep(currentStep + 1);
  };

  const handleBack = () =>
    currentStep > 0 && setCurrentStep(currentStep - 1);

  const handleSubmit = async () => {
    if (formData.fechaDanio > hoy) {
      return setErrorMsg("La fecha del daño no puede ser futura.");
    }
    if (parseFloat(formData.costo) <= 0) {
      return setErrorMsg("El costo debe ser mayor a 0.");
    }

    setLoading(true);
    try {
      await daniosService.crearDanio(formData);
      setLoading(false);
      alert("Daño registrado con éxito");
      navigate("/danios");
    } catch (error) {
      setLoading(false);
      console.error(error);
      alert("Error al registrar el daño");
    }
  };

  return (
    <div>
      {loading && <Loading message="Guardando daño..." />}

      <div className="card-header">
        <h1 className="card-title">Registrar Nuevo Daño</h1>
        <button
          className="btn btn-secondary"
          onClick={() => {
            setFormData({
              descripcion: "",
              fechaDanio: "",
              costo: "",
              alquiler_id: "",
            });
            setCurrentStep(0);
            setErrorMsg("");
          }}
        >
          ↺ Reiniciar
        </button>
      </div>

      <div className="card">
        <Steps steps={steps} currentStep={currentStep} />

        {/* STEP 1 */}
        {currentStep === 0 && (
          <div>
            <h3 style={{ marginBottom: 24, color: "var(--primary-blue)" }}>
              Datos del Daño
            </h3>

            {errorMsg && <Alert type="error" message={errorMsg} />}

            <FormInput
              label="Descripción"
              type="text"
              value={formData.descripcion}
              onChange={(val) => {
                setErrorMsg("");
                setFormData({ ...formData, descripcion: val });
              }}
              required
            />

            <FormInput
              label="Fecha del Daño"
              type="date"
              max={hoy}
              value={formData.fechaDanio}
              onChange={(val) => {
                setErrorMsg("");
                setFormData({ ...formData, fechaDanio: val });
              }}
              required
            />

            <FormInput
              label="Costo"
              type="number"
              min={1}
              value={formData.costo}
              onChange={(val) => {
                setErrorMsg("");
                setFormData({ ...formData, costo: val });
              }}
              required
            />

            <button
              className="btn btn-primary"
              onClick={handleNext}
              disabled={
                !formData.descripcion ||
                !formData.fechaDanio ||
                !formData.costo
              }
            >
              Continuar →
            </button>
          </div>
        )}

        {/* STEP 2 */}
        {currentStep === 1 && (
          <div>
            <h3 style={{ marginBottom: 24, color: "var(--primary-blue)" }}>
              Seleccionar Alquiler Asociado
            </h3>

            <FormSelect
              label="Alquiler"
              value={formData.alquiler_id}
              onChange={(val) => {
                setErrorMsg("");
                setFormData({ ...formData, alquiler_id: parseInt(val) });
              }}
              options={alquileres.map((a) => ({
                value: a.id,
                label: `ID ${a.id} — Cliente ${a.cliente_dni} — Vehículo ${a.vehiculo_patente}`,
              }))}
              required
            />

            <div className="u-flex u-gap-12" style={{ marginTop: 24 }}>
              <button className="btn btn-secondary" onClick={handleBack}>
                ← Volver
              </button>
              <button
                className="btn btn-primary"
                onClick={handleNext}
                disabled={!formData.alquiler_id}
              >
                Continuar →
              </button>
            </div>
          </div>
        )}

        {/* STEP 3 */}
       {currentStep === 2 && (
        <div>
          <h3 style={{ marginBottom: 24, color: "var(--primary-blue)" }}>
            Confirmar Datos del Daño
          </h3>

          <div className="detail-grid">
            <div className="detail-item">
              <strong>Descripción:</strong> {formData.descripcion}
            </div>

            <div className="detail-item">
              <strong>Fecha:</strong> {formData.fechaDanio}
            </div>

            <div className="detail-item">
              <strong>Costo:</strong> ${formData.costo}
            </div>
          </div>

          <h3 style={{ margin: "32px 0 16px", color: "var(--primary-blue)" }}>
            Información del Alquiler Asociado
          </h3>

          {/* Obtener alquiler seleccionado */}
          {(() => {
            const alq = alquileres.find(a => a.id === formData.alquiler_id);

            return (
              <div className="detail-grid">
                <div className="detail-item">
                  <strong>ID Alquiler:</strong> {alq?.id}
                </div>

                <div className="detail-item">
                  <strong>Cliente DNI:</strong> {alq?.cliente_dni}
                </div>

                <div className="detail-item">
                  <strong>Vehículo Patente:</strong> {alq?.vehiculo_patente}
                </div>

                
              </div>
            );
          })()}

          {errorMsg && <Alert type="error" message={errorMsg} />}

          <div className="u-flex u-gap-12" style={{ marginTop: 24 }}>
            <button className="btn btn-secondary" onClick={handleBack}>
              ← Volver
            </button>
            <button className="btn btn-success" onClick={handleSubmit}>
              Guardar Daño
            </button>
          </div>
        </div>
      )}

      </div>
    </div>
  );
}
