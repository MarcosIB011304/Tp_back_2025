import React, { use, useState } from 'react'
import Loading from '../../componentes/ui/Loading'
import Modal from '../../componentes/ui/Modal'
import FormSelect from '../../componentes/form/FormSelect'
import FormInput from '../../componentes/form/FormInput'
import {useClientes} from '../../hooks/UseClientes'
import { useVehiculosDisponibles } from '../../hooks/UseVehiculos'
import auxiliarNuevoAlquiler from '../../utils/auxiliarNuevoAlquiler'

function Steps({ steps, currentStep }) {
  return (
    <div className="steps-container">
      {steps.map((step, index) => (
        <div key={index} className={`step ${index === currentStep ? 'active' : ''} ${index < currentStep ? 'completed' : ''}`}>
          <div className="step-circle">{index < currentStep ? '✓' : index + 1}</div>
          <div className="step-label">{step}</div>
        </div>
      ))}
    </div>
  )
}

export default function CrearAlquiler() {
  const [currentStep, setCurrentStep] = useState(0)
  const [showPaymentModal, setShowPaymentModal] = useState(false)
  const [loading, setLoading] = useState(false)
  const [formData, setFormData] = useState({ fechaInicio: '', fechaFin: '', vehiculoPatente: '', clienteDni: null, metodoPago: '', montoAlquiler: null, montoCobrado: null })
  const steps = ['Fechas', 'Vehículo', 'Cliente', 'Resumen', 'Pago']
  const {clientes, loadingClientes, errorClientes, fetchClientes} = useClientes()
  const handleNext = () => currentStep < steps.length - 1 && setCurrentStep(currentStep + 1)
  const handleBack = () => currentStep > 0 && setCurrentStep(currentStep - 1)
  const {vehiculosDisponibles, loadingVD, errorVD, fetchVD} = useVehiculosDisponibles({inicio: formData.fechaInicio, fin: formData.fechaFin})
  const [codigoIngresado, setCodigoIngresado] = useState('')
  const [tarjeta, setTarjeta] = useState({nroTarjeta: '', titular:'', vecimiento:'', cvv:''})
  const codigoSucursal = '12fg354'

  const handleFinalizarPago =async() => {
    setLoading(true)
    setTimeout(async () => {
      try{
        const cargaDatos = await auxiliarNuevoAlquiler.transaccionNuevoAlquiler(formData)
        if (cargaDatos){
        setLoading(false); setShowPaymentModal(false)
        alert('¡Alquiler registrado exitosamente! Seña del 40% cobrada.')
        setCurrentStep(0); setFormData({ fechaInicio: '', fechaFin: '', vehiculoId: '', clienteDni: '', metodoPago: '' })
        }
        else{
          setLoading(false); setShowPaymentModal(false)
          alert('Error al registrar el alquiler.')
        }
      }
      catch(error){
        console.error("ERROR AL REGISTRAR EL PAGO", error.message)
      }
      
    })
  }

  
  const calcularTotal = () => {
    if (!formData.fechaInicio || !formData.fechaFin || !formData.vehiculoPatente) return 0
    const v = vehiculosDisponibles.find(v => v.patente === (formData.vehiculoPatente))
    console.log(v)
    const dias = Math.ceil((new Date(formData.fechaFin) - new Date(formData.fechaInicio)) / (1000*60*60*24))
    if (dias < 1) {return v.precioPorDia}
    console.log(v.precioPorDia)
    console.log(dias)
    const precioAlquiler = v.precioPorDia * dias 
    return parseFloat(precioAlquiler)
  }

  return (
    <div>
      {loading && <Loading message="Procesando pago..." />}

      <div className="card-header">
        <h1 className="card-title">Nuevo Alquiler</h1>
        <button className="btn btn-secondary" onClick={() => setCurrentStep(0)}>↺ Reiniciar</button>
      </div>

      <div className="card">
        <Steps steps={steps} currentStep={currentStep} />

        {currentStep === 0 && (
          <div>
            <h3 style={{ marginBottom: 24, color: 'var(--primary-blue)' }}>Seleccionar Fechas de Alquiler</h3>
            <div className="form-row">
              <FormInput label="Fecha de Inicio" type="date" value={formData.fechaInicio} onChange={val => setFormData({ ...formData, fechaInicio: val })} required />
              <FormInput label="Fecha de Fin"    type="date" value={formData.fechaFin}    onChange={val => setFormData({ ...formData, fechaFin: val })} required />
            </div>
            <button className="btn btn-primary" onClick={handleNext} disabled={!formData.fechaInicio || !formData.fechaFin}>Continuar →</button>
          </div>
        )}

        {currentStep === 1 && (
          <div>
            <h3 style={{ marginBottom: 24, color: 'var(--primary-blue)' }}>Seleccionar Vehículo Disponible</h3>
            {vehiculosDisponibles.map(v => (
              <div key={v.patente} className={`vehicle-card ${formData.vehiculoPatente === String(v.patente) ? 'selected' : ''}`} onClick={() => setFormData({ ...formData, vehiculoPatente: String(v.patente) })}>
                <div className="vehicle-header">
                  <div className="vehicle-info"><h3>{v.modelo.nombre}</h3><p style={{ color: 'var(--text-light)' }}>{v.año}</p></div>
                  <div className="vehicle-price">${v.precioPorDia}/día</div>
                </div>
                <div className="vehicle-details">
                  <div className="vehicle-detail"><strong>Color:</strong> {v.color}</div>
                  <div className="vehicle-detail"><strong>Año:</strong> {v.añoModelo}</div>
                </div>
              </div>
            ))}
            <div className="u-flex u-gap-12" style={{ marginTop: 24 }}>
              <button className="btn btn-secondary" onClick={handleBack}>← Volver</button>
              <button className="btn btn-primary" onClick={handleNext} disabled={!formData.vehiculoPatente}>Continuar →</button>
            </div>
          </div>
        )}

        {currentStep === 2 && (
          <div>
            <h3 style={{ marginBottom: 24, color: 'var(--primary-blue)' }}>Seleccionar Cliente</h3>
            <FormSelect
              label="Cliente"
              value={formData.clienteDni}
              key={clientes.dni}
              onChange={val => setFormData({ ...formData, clienteDni: parseInt(val) })}
              options={clientes.map(c => ({ value: c.dni, label: `${c.nombre} - DNI: ${c.dni}` }))}
              required
            />
            <button className="btn btn-secondary btn-sm" style={{ marginBottom: 24 }}>➕ Crear Nuevo Cliente</button>
            <div className="u-flex u-gap-12">
              <button className="btn btn-secondary" onClick={handleBack}>← Volver</button>
              <button className="btn btn-primary" onClick={handleNext} disabled={!formData.clienteDni}>Continuar →</button>
            </div>
          </div>
        )}

        {currentStep === 3 && (
          <div>
            <h3 style={{ marginBottom: 24, color: 'var(--primary-blue)' }}>Resumen del Alquiler</h3>
            <div className="detail-grid">
              <div className="detail-item"><div className="detail-label">Fecha Inicio</div><div className="detail-value">{formData.fechaInicio}</div></div>
              <div className="detail-item"><div className="detail-label">Fecha Fin</div><div className="detail-value">{formData.fechaFin}</div></div>
              <div className="detail-item"><div className="detail-label">Cliente</div><div className="detail-value">{clientes.find(c => c.dni === parseInt(formData.clienteDni))?.nombre}</div></div>
              <div className="detail-item"><div className="detail-label">DNI Cliente</div><div className="detail-value">{clientes.find(c => c.dni === parseInt(formData.clienteDni))?.dni}</div></div>
              <div className="detail-item"><div className="detail-label">Vehículo</div><div className="detail-value">
                {vehiculosDisponibles.find(v => v.patente === (formData.vehiculoPatente))?.marca} {vehiculosDisponibles.find(v => v.patente === (formData.vehiculoPatente))?.modelo.nombre}
              </div></div>
              <div className="detail-item"><div className="detail-label">Total</div><div className="detail-value" style={{ color: 'var(--accent-blue)', fontSize: 20 }}>${calcularTotal()}</div></div>
            </div>
            <div className="u-flex u-gap-12" style={{ marginTop: 24 }}>
              <button className="btn btn-secondary" onClick={handleBack}>← Volver</button>
              <button className="btn btn-primary" onClick={handleNext}>Continuar al Pago →</button>
            </div>
          </div>
        )}

        {currentStep === 4 && (
          <div>
            <h3 style={{ marginBottom: 24, color: 'var(--primary-blue)' }}>Método de Pago</h3>
            <p style={{ marginBottom: 24, color: 'var(--text-light)' }}>
              Seña requerida: <strong style={{ color: 'var(--accent-blue)', fontSize: 20 }}>${(calcularTotal() * 0.4).toFixed(2)}</strong> (40% del total)
            </p>

            <div style={{ display: 'grid', gap: 16, marginBottom: 24 }}>
              <div className={`vehicle-card ${formData.metodoPago === 'efectivo' ? 'selected' : ''}`} onClick={() => setFormData({ ...formData, metodoPago: 'efectivo', montoAlquiler: calcularTotal() })}>
                <h3>💵 Efectivo</h3>
                <p style={{ color: 'var(--text-light)', marginTop: 8 }}>Pago en sucursal con código de validación</p>
              </div>
              <div className={`vehicle-card ${formData.metodoPago === 'tarjeta' ? 'selected' : ''}`} onClick={() => setFormData({ ...formData, metodoPago: 'tarjeta', montoAlquiler: calcularTotal()})}>
                <h3>💳 Tarjeta de Crédito</h3>
                <p style={{ color: 'var(--text-light)', marginTop: 8 }}>Pago inmediato con tarjeta</p>
              </div>
            </div>

            {formData.metodoPago === 'efectivo' && (
              <div style={{ padding: 20, background: 'var(--light-gray)', borderRadius: 8, marginBottom: 24 }}>
                <FormInput label="Código de Validación" placeholder="Ingrese el código de la sucursal" type='text' value={codigoIngresado}  onChange={(val)=>setCodigoIngresado(val)} required={true} />
              </div>
            )}

            <div className="u-flex u-gap-12">
              <button className="btn btn-secondary" onClick={handleBack}>← Volver</button>
              <button
                className="btn btn-success"
                onClick={() => formData.metodoPago === 'tarjeta' ? setShowPaymentModal(true) : codigoIngresado == codigoSucursal? handleFinalizarPago(): alert("El codigo ingresado no es correcto")}
                disabled={!formData.metodoPago} 
              >
                Confirmar Pago
              </button>
            </div>
          </div>
        )}
      </div>

      <Modal
        isOpen={showPaymentModal}
        onClose={() => setShowPaymentModal(false)}
        title="Datos de Tarjeta de Crédito"
        footer={
          <>
            <button className="btn btn-secondary" onClick={() => setShowPaymentModal(false)}>Cancelar</button>
            <button className="btn btn-success" onClick={handleFinalizarPago}>Procesar Pago</button>
          </>
        }
      >
        <FormInput label="Número de Tarjeta" placeholder="1234 5678 9012 3456" type='number' value={tarjeta.nroTarjeta} onChange={(val)=>setTarjeta({...tarjeta, nroTarjeta:val })} required={true}/>
        <div className="form-row">
          <FormInput label="Fecha de Vencimiento" placeholder="MM/AA" type='date' value={tarjeta.vecimiento} onChange={(val)=>setTarjeta({...tarjeta, vecimiento:val})} required={true} />
          <FormInput label="CVV" placeholder="123" value={tarjeta.cvv} onChange={(val)=>setTarjeta({...tarjeta, cvv:val})} required={true} />
        </div>
        <FormInput label="Nombre del Titular" placeholder="Como aparece en la tarjeta" type='text' value={tarjeta.titular} onChange={(val)=>setTarjeta({...tarjeta, titular:val})} required={true} />
      </Modal>
    </div>
  )
}
