import apiClient from "./apiClient";

const getCobros = async ()=>{
    const response = await apiClient.get("/cobros")
    return response.data
}
const nuevoCobro = async(nuevoCobro)=>{
    const response = await  apiClient.post("/cobros", nuevoCobro)
    return response.data

}

const cobrosService = {getCobros, nuevoCobro}

export default cobrosService;