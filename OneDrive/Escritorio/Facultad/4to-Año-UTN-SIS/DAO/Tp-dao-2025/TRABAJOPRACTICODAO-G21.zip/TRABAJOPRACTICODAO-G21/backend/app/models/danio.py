from sqlalchemy import Integer, String, Float, Date, ForeignKey
from sqlalchemy.orm import Mapped, mapped_column, relationship
from app.db import Base

class Danio(Base):
    __tablename__ = "Danio"   # ← debe coincidir EXACTO con la DB

    id: Mapped[int] = mapped_column(Integer, primary_key=True, index=True)
    descripcion: Mapped[str] = mapped_column(String(255))
    fechaDanio: Mapped[Date] = mapped_column(Date)
    costo: Mapped[float] = mapped_column(Float)

    alquiler_id: Mapped[int] = mapped_column(ForeignKey("Alquiler.id"))
    alquiler = relationship("Alquiler", back_populates="danios")