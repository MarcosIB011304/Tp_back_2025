import vehiculosService from "../services/vehiculosService";


const creacionNuevoVehiculo = async(data)=>{
    const nuevoVehiculo = {patente: data.patente, añoModelo: data.añoModelo, añoIngreso: data.añoIngreso, kilometros: data.kilometros, color: data.color, precioPorDia: data.precioPordia, modelo_id: data.modelo_id, disponibleHoy: true}

    try {
        const response = await vehiculosService.crearVehiculo(nuevoVehiculo)
        console.log("Vehiculo creado con éxito")
        return response
    }
    catch(error) {
        console.error("Error al crear el vehículo", error.message)
        return error
    }
}


const actualizarKilometros=async(patente, kilometrosASumar)=>{
    
}