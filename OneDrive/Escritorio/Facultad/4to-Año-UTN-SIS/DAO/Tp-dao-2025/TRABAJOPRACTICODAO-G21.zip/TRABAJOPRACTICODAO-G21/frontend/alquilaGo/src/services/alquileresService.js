import apiClient from "./apiClient"

// gett todos los alquileres

const getAlquileres = async()=>{
    const response = await apiClient.get('/alquileres/')
    return response.data
}

const crearAlquiler = async(nuevoAlquiler)=>{
    
    const response = await apiClient.post('/alquileres/', nuevoAlquiler)
    return response.data
}

const getAlquilerPorId = async(id)=>{
    const response = await apiClient.get(`/alquileres/${id}`)
    return response.data
}

const getAlquileresCliente = async(dni)=>{
    const response = await apiClient.get(`/alquileres/cliente/${dni}`)
    return response.data
}

const finalizarAlquiler= async(id)=> {
    const response = await apiClient.patch(`/alquileres/finalizar/${id}`)
    return response.data
}

const alquileresService = {crearAlquiler, getAlquileres, getAlquilerPorId, getAlquileresCliente, finalizarAlquiler}
export default alquileresService