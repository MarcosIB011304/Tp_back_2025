from typing import Optional
from datetime import date
from pydantic import Field, BaseModel
from pydantic import BaseModel, EmailStr, Field, ConfigDict 
from .vehiculo import MarcaSimpleOut, VehiculoSimpleOut
from .cliente import ClienteSimpleOut
from .cobro import CobroOut

#Alquiler

class AlquilerBase(BaseModel):
    cliente_dni: int 
    empleado_dni: int
    fechaDeGestion: date
    fechaFin: date
    fechaDelnicio: date
    vehiculo_patente: str = Field(..., min_length=6, max_length=12)
    montoAlquiler: float 
class AlquilerCreate(AlquilerBase):
    pass

class AlquilerOut(AlquilerBase):
    id: int
    vehiculo: VehiculoSimpleOut
    cliente: ClienteSimpleOut
    cobros: list[CobroOut]
class AlquilerSimpleOut(AlquilerBase):
    id: int
    vehiculo_patente: str


AlquilerOut.model_rebuild()