import React from 'react'

export default function FormInput({
  label,
  type = 'text',
  value,
  onChange,
  placeholder,
  required,
  name
}) {
  return (
    <div className="form-group">
      <label className="form-label">
        {label} {required && <span style={{ color: 'var(--danger)' }}>*</span>}
      </label>

      <input
        type={type}
        className="form-input"
        name={name}
        value={value ?? ""}
        onChange={onChange} // ← ESTE ES EL CAMBIO CLAVE
        placeholder={placeholder}
        required={required}
      />
    </div>
  );
}
