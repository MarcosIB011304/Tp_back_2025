from datetime import date
from pydantic import BaseModel

class DanioBase(BaseModel):
    descripcion: str
    fechaDanio: date     
    costo: float
    alquiler_id: int

class DanioCreate(DanioBase):
    pass

class DanioOut(DanioBase):
    id: int

class DanioSimpleOut(BaseModel):
    id: int
    descripcion: str
    costo: float
